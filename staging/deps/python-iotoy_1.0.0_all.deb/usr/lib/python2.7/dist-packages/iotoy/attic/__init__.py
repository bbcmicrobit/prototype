# This is where old code is retired to
#
# It's going to hang around for a bit in case it's useful to show
# historical development to the casual poker-arounder who doesn't
# want to rummage around in version control history.
#
