IOTOY Python
============
This is the collection of IOToy modules and experiments built. It will get tidied up ASAP.

FIXME: Needs documenting

Currently Missing:
  * Non-local external proxy via httptunnel or similar.
    (easy to bolt on, but needs integrating)
  * Websockets for data subscribe / data publish
    - To be represented as channels (active queues) with callbacks
